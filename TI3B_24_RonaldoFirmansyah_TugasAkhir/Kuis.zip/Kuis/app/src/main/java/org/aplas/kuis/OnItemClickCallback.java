package org.aplas.kuis;

public interface OnItemClickCallback {
    void onitemClicked(Protokol protokol);
}
